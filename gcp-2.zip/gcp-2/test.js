console.log('Node.js is working correctly!');
